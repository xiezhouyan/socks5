<?php

if ( !class_exists('Puc_v4_Fifu_Factory', false) ):

	class Puc_v4_Fifu_Factory extends Puc_v4p11_Fifu_Factory { }

endif;
